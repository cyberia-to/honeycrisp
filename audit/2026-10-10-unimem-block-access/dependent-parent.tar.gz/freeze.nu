def main [] {
  let root = $env.FILE_PWD
  let scenarios = (open ($root | path join scenarios.json))
  let failures = [
    {scenario: 'glia-localresolved', repo: glia, path: 'run/tests/tier5_graph_ir.rs', failure: 'E0063 missing has_attn_bias at line22'}
    {scenario: 'mir-localresolved', repo: mir, path: 'src/gpu.rs', failure: 'E0599 missing Gpu::sync at line32'}
    {scenario: xena, repo: xena, path: 'crates/xena-bench/src/gpudebug.rs', failure: 'E0608 indexing unit at lines192/195'}
    {scenario: 'erga-localresolved', repo: erga, path: 'rs/app/src/chime.rs', failure: 'debug tests panic: multiply overflow at line132'}
  ]
  $failures | each {|f|
    let s = ($scenarios | where repo == $f.scenario | first)
    let full = ($s.cwd | path join $f.path)
    $f | insert revision ($s.inputs | where repo == $f.repo | first | get pin)
      | insert full_path $full | insert sha256 (open --raw $full | hash sha256)
  } | to json | save --force ($root | path join failing-source.json)
  let rows = (open ($root | path join commands.json) | each {|r|
    let stem = ($root | path join logs $r.repo $r.label)
    let stdout = (open --raw $"($stem).stdout")
    let stderr = (open --raw $"($stem).stderr")
    let totals = ($stdout | lines | parse -r '^test result: (?:ok|FAILED)\. (?<passed>\d+) passed; (?<failed>\d+) failed; (?<ignored>\d+) ignored; (?<measured>\d+) measured; (?<filtered>\d+) filtered out;' | each {|t| $t | update cells {|v| $v | into int}})
    {scenario: $r.repo, label: $r.label, cargo_exit: $r.exit_code,
      first_error: ($stderr | lines | where {|s| $s | str starts-with 'error'} | first 1),
      first_warning: ($stderr | lines | where {|s| $s | str starts-with 'warning'} | first 1),
      tests: $totals}
  })
  $rows | to json | save --force ($root | path join outcomes.json)
  let files = (glob ($root | path join '*') | where {|p| ($p | path type) == file and ($p | path basename) != SHA256SUMS }
    | append (glob ($root | path join logs '*' '*'))
    | append (glob ($root | path join retained-locks '*')) | sort)
  $files | each {|f| $"(open --raw $f | hash sha256)  ($f | path relative-to $root)"} | str join (char nl) | save --force ($root | path join SHA256SUMS)
  $rows | select scenario label cargo_exit
}
