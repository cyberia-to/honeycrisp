def main [] {
  let root = $env.FILE_PWD
  let archives = (open /tmp/unimem-access-origins.knYGlE/archives.json)
  mut scenarios = (open ($root | path join scenarios.json))
  for repo in [bita glia] {
    let scenario = $"($repo)-localresolved"
    let source = ($root | path join scenarios $scenario source)
    mkdir $source
    mut inputs = []
    for name in [$repo honeycrisp strata] {
      let input = ($archives | where repo == $name | first)
      let dest = ($source | path join $name)
      mkdir $dest
      let r = (^tar -xf $input.archive -C $dest | complete)
      if $r.exit_code != 0 { error make {msg: $r.stderr} }
      $inputs = ($inputs | append ($input | select repo pin sha256 locks))
    }
    $inputs | to json | save ($source | path dirname | path join sources.json)
    $scenarios = ($scenarios | append {repo: $scenario, cwd: ($source | path join $repo), inputs: $inputs})
  }
  $scenarios | to json | save --force ($root | path join scenarios.json)
}
