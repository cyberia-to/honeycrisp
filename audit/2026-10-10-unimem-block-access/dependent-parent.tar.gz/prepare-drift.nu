def main [] {
  let root = $env.FILE_PWD
  let archives = (open /tmp/unimem-access-origins.knYGlE/archives.json)
  mut scenarios = (open ($root | path join scenarios.json))
  for repo in [mir erga nox] {
    let original = ($scenarios | where repo == $repo | first)
    let scenario = $"($repo)-localresolved"
    let source = ($root | path join scenarios $scenario source)
    if ($source | path exists) { error make {msg: $"refuse existing ($source)"} }
    mkdir $source
    for pin in $original.inputs {
      let input = ($archives | where repo == $pin.repo | first)
      let dest = ($source | path join $input.repo)
      mkdir $dest
      let r = (^tar -xf $input.archive -C $dest | complete)
      if $r.exit_code != 0 { error make {msg: $r.stderr} }
    }
    $original.inputs | to json | save ($source | path dirname | path join sources.json)
    $scenarios = ($scenarios | append {repo: $scenario, cwd: ($source | path join $repo), inputs: $original.inputs})
  }
  $scenarios | to json | save --force ($root | path join scenarios.json)
}
