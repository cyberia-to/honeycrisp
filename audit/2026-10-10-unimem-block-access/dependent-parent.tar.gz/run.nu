def lock-state [cwd: path] {
  let p = ($cwd | path join Cargo.lock)
  if ($p | path exists) { {exists: true, sha256: (open --raw $p | hash sha256)} } else { {exists: false, sha256: null} }
}
def --wrapped main [repo: string, label: string, ...args: string] {
  let root = $env.FILE_PWD
  let s = (open ($root | path join scenarios.json) | where repo == $repo | first)
  let logs = ($root | path join logs $repo)
  mkdir $logs
  let record = ($logs | path join $"($label).json")
  if ($record | path exists) { error make {msg: $"refusing overwrite ($record)"} }
  let toolchain = if $repo == nika { 'nightly-2025-11-26' } else { '1.95.0' }
  let cargo = (^rustup which --toolchain $toolchain cargo | str trim)
  let rustc = (^rustup which --toolchain $toolchain rustc | str trim)
  let rustdoc = (^rustup which --toolchain $toolchain rustdoc | str trim)
  let target = ($root | path join targets $repo)
  let envs = {RUSTC: $rustc, RUSTDOC: $rustdoc, CARGO_TARGET_DIR: $target, CARGO_BUILD_JOBS: '2', CARGO_INCREMENTAL: '0'}
  let envs = if $label in [build-release-bootstrap difftest-bootstrap] { $envs | insert RUSTC_BOOTSTRAP '1' } else { $envs }
  let before = (lock-state $s.cwd)
  let start = (date now)
  let result = (with-env $envs { cd $s.cwd; run-external $cargo ...$args | complete })
  let end = (date now)
  $result.stdout | save ($logs | path join $"($label).stdout")
  $result.stderr | save ($logs | path join $"($label).stderr")
  {repo: $repo, label: $label, cwd: $s.cwd, command: $cargo, args: $args, environment: $envs,
   start: ($start | format date '%+'), end: ($end | format date '%+'), elapsed: (($end - $start) | into string),
   exit_code: $result.exit_code, lock_before: $before, lock_after: (lock-state $s.cwd)} | to json | save $record
  print $"($repo)/($label) exit=($result.exit_code) elapsed=($end - $start)"
  print ($result.stderr | lines | first 12 | str join (char nl))
}
