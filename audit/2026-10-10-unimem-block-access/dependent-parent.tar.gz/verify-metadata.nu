def main [] {
  let root = $env.FILE_PWD
  mut receipts = []
  for f in (glob ($root | path join logs '*' 'metadata*.json')) {
    let record = (open $f)
    if $record.exit_code != 0 { continue }
    let data = (open --raw ($f | str replace '.json' '.stdout') | from json)
    let expected = ($root | path join scenarios $record.repo source | path expand)
    let local = ($data.packages | where source == null | select name version manifest_path)
    for p in $local {
      if not ($p.manifest_path | str starts-with $"($expected)/") {
        error make {msg: $"source escaped: ($p.manifest_path) expected ($expected)"}
      }
    }
    $receipts = ($receipts | append {repo: $record.repo, label: $record.label, expected_source_root: $expected, local: $local,
      drivers: ($local | where name in [unimem aruminium acpu rane]),
      registry_count: ($data.packages | where source != null | length), lock: $record.lock_after})
  }
  $receipts | to json | save --force ($root | path join metadata-paths.json)
  $receipts | each {|r| {repo: $r.repo, label: $r.label, drivers: ($r.drivers | get name | str join ','), local_packages: ($r.local | length)}}
}
