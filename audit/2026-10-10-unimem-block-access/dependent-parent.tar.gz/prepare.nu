def main [] {
  let root = $env.FILE_PWD
  let archives = (open /tmp/unimem-access-origins.knYGlE/archives.json)
  let scenarios = [
    {repo: mir, deps: [honeycrisp strata]}
    {repo: bita, deps: [honeycrisp strata]}
    {repo: erga, deps: [honeycrisp strata]}
    {repo: glia, deps: [honeycrisp strata]}
    {repo: perla, deps: [honeycrisp strata]}
    {repo: xena, deps: [honeycrisp strata]}
    {repo: zoya, deps: [honeycrisp strata]}
    {repo: evy, deps: [honeycrisp strata hemera bbg lens nox zheng]}
    {repo: nox, deps: [strata hemera lens]}
    {repo: nika, deps: [honeycrisp strata]}
    {repo: trisha, deps: [honeycrisp strata hemera trident zheng nox lens]}
    {repo: cyb, deps: [honeycrisp strata hemera mir glia evy bbg lens nox zheng]}
  ]
  mut rows = []
  for s in $scenarios {
    let source = ($root | path join scenarios $s.repo source)
    mkdir $source
    mut inputs = []
    for name in ($s.deps | prepend $s.repo) {
      let input = ($archives | where repo == $name | first)
      if (open --raw $input.archive | hash sha256) != $input.sha256 { error make {msg: $"archive mismatch ($name)"} }
      let dest = ($source | path join $name)
      mkdir $dest
      let r = (^tar -xf $input.archive -C $dest | complete)
      if $r.exit_code != 0 { error make {msg: $r.stderr} }
      $inputs = ($inputs | append ($input | select repo pin sha256 locks))
    }
    $inputs | to json | save ($source | path dirname | path join sources.json)
    $rows = ($rows | append {repo: $s.repo, cwd: ($source | path join $s.repo), inputs: $inputs})
  }
  $rows | to json | save ($root | path join scenarios.json)
}
