def main [] {
  let root = $env.FILE_PWD
  let catalog = (open /tmp/unimem-access-origins.knYGlE/archives.json)
  let scenarios = (open ($root | path join scenarios.json))
  mkdir ($root | path join retained-locks)
  mut locks = []
  for name in [bita glia mir erga nox] {
    let dest = ($root | path join retained-locks $"($name).Cargo.lock")
    cp --force ($root | path join scenarios $"($name)-localresolved" source $name Cargo.lock) $dest
    let original = ($catalog | where repo == $name | first | get destination | path join Cargo.lock)
    let delta = if ($original | path exists) { ^diff -u $original $dest | complete } else { {exit_code: 1, stdout: 'No committed Cargo.lock; new local resolution.', stderr: ''} }
    $delta.stdout | save --force ($root | path join retained-locks $"($name).diff")
    $locks = ($locks | append {repo: $name, path: $dest, sha256: (open --raw $dest | hash sha256), status: 'authorized local resolution; not origin-locked', diff_exit: $delta.exit_code})
  }
  $locks | to json | save --force ($root | path join retained-locks manifest.json)
  mut comparison = []
  for s in $scenarios {
    for input in $s.inputs {
      let original = ($catalog | where repo == $input.repo | first | get destination)
      let extracted = ($s.cwd | path dirname | path join $input.repo)
      let r = (^diff -qr $original $extracted | complete)
      $comparison = ($comparison | append {scenario: $s.repo, repo: $input.repo, original: $original, extracted: $extracted, revision: $input.pin,
        archive_sha256: $input.sha256, command: ['diff' '-qr' $original $extracted], exit_code: $r.exit_code, stdout: $r.stdout, stderr: $r.stderr})
    }
  }
  $comparison | to json | save --force ($root | path join source-comparison.json)
  let records = (glob ($root | path join logs '*' '*.json') | each {|f| open $f} | sort-by start)
  $records | to json | save --force ($root | path join commands.json)
  let tools = (['1.95.0' 'nightly-2025-11-26'] | each {|name|
    let cargo = (^rustup which --toolchain $name cargo | str trim)
    let rustc = (^rustup which --toolchain $name rustc | str trim)
    let rustdoc = (^rustup which --toolchain $name rustdoc | str trim)
    {toolchain: $name, cargo: $cargo, cargo_version: (run-external $cargo ...['--version'] | complete), rustc: $rustc,
      rustc_version: (run-external $rustc ...['-vV'] | complete), rustdoc: $rustdoc, rustdoc_version: (run-external $rustdoc ...['--version'] | complete)}
  })
  {tools: $tools, inherited: ($env | select --optional RUSTFLAGS RUSTDOCFLAGS RUSTC_WRAPPER CARGO_ENCODED_RUSTFLAGS RUSTC_BOOTSTRAP CARGO_HOME),
    platform: (^uname -a | complete), disk: (^df -h /tmp | complete), targets: (^du -sh ($root | path join targets) | complete)} | to json | save --force ($root | path join tool-environment.json)
  $comparison | where exit_code != 0 | select scenario repo exit_code stdout
}
