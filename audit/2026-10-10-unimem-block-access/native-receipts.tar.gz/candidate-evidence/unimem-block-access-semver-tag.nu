def main [] {
    let root = '/tmp/unimem-block-access-validation-6eQqO1'
    let repo = '/Users/master/cyber/honeycrisp-kadek-block-access'
    let revision = '96fa4f4509d7a966cb22a4bb9e12ac753cff43ae'
    let destination = ($root | path join 'historical/honeycrisp')
    if ($destination | path exists) { error make {msg: 'historical archive exists'} }
    mkdir $destination
    let archive = ($root | path join 'archives/honeycrisp-v0.2.0.tar')
    let archive_result = (^git -C $repo archive --format=tar --output $archive $revision | complete)
    if $archive_result.exit_code != 0 { error make {msg: $archive_result.stderr} }
    let extract = (^tar -xf $archive -C $destination | complete)
    if $extract.exit_code != 0 { error make {msg: $extract.stderr} }
    let original = (open ($root | path join 'receipts/candidate/semver-parent/result.json'))
    let logs = ($root | path join 'receipts/candidate/semver-tag-unimem')
    mkdir $logs
    let command = ($original.command | update directory ($root | path join 'candidate/honeycrisp/unimem') | update arguments ['run', '1.95.0', 'cargo', 'semver-checks', '--manifest-path', ($root | path join 'candidate/honeycrisp/unimem/Cargo.toml'), '-p', 'unimem', '--baseline-root', ($destination | path join unimem), '--verbose'])
    $command | to nuon | save ($logs | path join command.nuon)
    $original.resolved_tools | to json | save ($logs | path join resolved-tools.json)
    let input = {tag: 'v0.2.0', revision: $revision, archive: $archive, sha256: (open --raw $archive | hash sha256), historical_sibling: '../nebu/rs', historical_sibling_pin: null, note: 'No historical sibling pin exists in tag manifest; no substituted sibling or manifest edit. This attempts dependency resolution, not a claim of a complete historical closure.'}
    $input | to json | save ($logs | path join historical-input.json)
    let started = (date now)
    cd $command.directory
    let result = (with-env $command.environment { run-external $command.program ...$command.arguments | complete })
    $result.stdout | save ($logs | path join stdout)
    $result.stderr | save ($logs | path join stderr)
    $result.exit_code | into string | save ($logs | path join exit)
    let lock_after = (open --raw ($root | path join 'candidate/honeycrisp/Cargo.lock') | hash sha256)
    ($original | update gate 'semver-tag-unimem' | update label 'semver-tag-unimem' | update command $command | update started ($started | format date '%+') | update finished (date now | format date '%+') | update exit_code $result.exit_code | update lock_after $lock_after | update lock_unchanged ($lock_after == $original.lock_before) | update runner_sha256 (open --raw $env.CURRENT_FILE | hash sha256) | insert historical_input $input) | to json | save ($logs | path join result.json)
    print {exit: $result.exit_code, logs: $logs}
}
