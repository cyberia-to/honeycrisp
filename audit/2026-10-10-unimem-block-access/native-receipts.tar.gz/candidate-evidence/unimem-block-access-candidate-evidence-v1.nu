def main [] {
    let root = '/tmp/unimem-block-access-validation-6eQqO1'
    let overlay = (open ($root | path join overlay.json))
    mut source_checks = []
    for suite in [parent candidate] {
        for repo in [honeycrisp strata] {
            let base = (open ($root | path join archives $'($repo)-files.json'))
            let expected = (if $suite == 'candidate' and $repo == 'honeycrisp' { $base | where {|row| $row.path not-in $overlay.files.path } | append $overlay.files } else { $base })
            let directory = ($root | path join $suite $repo)
            let wrong = ($expected | where {|row| (open --raw ($directory | path join $row.path) | hash sha256) != $row.sha256 })
            let files = (glob --no-dir $'($directory)/**/*' | each { path relative-to $directory })
            let extras = ($files | where {|path| $path not-in $expected.path })
            if not ($wrong | is-empty) or not ($extras | is-empty) { error make {msg: $'unexpected archive changes in ($suite)/($repo)'} }
            $source_checks = ($source_checks | append {suite: $suite, repository: $repo, expected_file_count: ($expected | length), mismatches: $wrong, additional_paths: $extras})
        }
    }
    $source_checks | to json | save ($root | path join candidate-source-postcheck.json)
    let freeze = ($overlay.files | each {|row| {path: $row.path, expected: $row.sha256, actual: (open --raw ($overlay.source | path join $row.path) | hash sha256)}})
    if not ($freeze | where {|row| $row.expected != $row.actual } | is-empty) { error make {msg: 'owned source freeze changed'} }
    $freeze | to json | save ($root | path join candidate-freeze-postcheck.json)
    let results = (glob ($root | path join 'receipts/candidate/*/result.json') | each {|path|
        let r = (open $path)
        {label: $r.label, exit: $r.exit_code, started: $r.started, finished: $r.finished, lock_unchanged: $r.lock_unchanged, program: $r.command.program, args: $r.command.arguments, receipt: ($path | path dirname)}
    } | sort-by started)
    if ($results | any {|r| not $r.lock_unchanged }) { error make {msg: 'lock changed'} }
    $results | to json | save ($root | path join candidate-results.json)
    let strict = (['parent' 'candidate'] | each {|suite|
        let text = (open --raw ($root | path join receipts $suite clippy stderr) | lines | where {|line| $line !~ '^ *(Checking|Compiling) ' and $line != 'warning: build failed, waiting for other jobs to finish...' } | str join '\n')
        {suite: $suite, filtered: $text, sha256: ($text | hash sha256)}
    })
    {normalization: 'Remove only Cargo Checking/Compiling progress and build-wait line; retain every error, source span, suggestion, note and blank line.', parent: $strict.0, candidate: $strict.1, equal: ($strict.0.filtered == $strict.1.filtered)} | to json | save ($root | path join candidate-clippy-strict-comparison.json)
    let comparison = (open ($root | path join receipts candidate clippy-warnings diagnostic-comparison.json))
    let fixtures = (open ($root | path join receipts parent clippy-fixtures-warnings diagnostics.json))
    let added = ($comparison.added | each {|item|
        let outer = ($item | from json)
        let d = ($outer.value | from json)
        let file = $d.spans.0.file
        let old = (open --raw ($root | path join parent honeycrisp $file))
        let new = (open --raw ($root | path join candidate honeycrisp $file))
        let witnessed = ($fixtures | any {|row| $row.target == $d.target and $row.code == $d.code and $row.message == $d.message and ($row.spans | get text | flatten) == ($d.spans | get text | flatten) })
        {target: $d.target, code: $d.code, source: $file, primary: $d.spans, count: $outer.count, source_unchanged: ($old == $new), parent_source_sha256: ($old | hash sha256), candidate_source_sha256: ($new | hash sha256), witnessed_by_parent_fixture_gate: $witnessed, classification: (if $witnessed { 'Same warning emitted by exact-parent fixture gate; shifted line numbers remain in raw logs.' } else if $old == $new { 'Unchanged example source and same toolchain; previously masked in failed parent full invocation.' } else { error make {msg: 'unattributed warning difference'} })}
    })
    let removed = ($comparison.removed | each {|item| let o = ($item | from json); let d = ($o.value | from json); {target: $d.target, level: $d.level, code: $d.code, count: $o.count} } | group-by target | transpose target records | each {|group| {target: $group.target, count: ($group.records.count | math sum), source: 'aruminium/benches/wgpu_bench.rs', source_unchanged: ((open --raw ($root | path join parent honeycrisp aruminium/benches/wgpu_bench.rs)) == (open --raw ($root | path join candidate honeycrisp aruminium/benches/wgpu_bench.rs))), classification: 'Masked failed target; not a removed defect. Parent saw 35 E0433 plus its failure note, candidate did not emit this target.'} })
    {added: $added, removed: $removed, interpretation: 'Different emitted target sets from two failed parallel gates. No full-workspace completeness or baseline improvement claim. Selected fixture gate diagnostics match exactly.'} | to json | save ($root | path join candidate-clippy-warning-attribution.json)
    print {receipts: ($results | length), source_checks: $source_checks, strict_clippy_equal: ($strict.0.filtered == $strict.1.filtered), warning_additions: ($added | length)}
}
