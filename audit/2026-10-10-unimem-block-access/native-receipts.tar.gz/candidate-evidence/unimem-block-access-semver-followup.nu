def main [] {
    let root = '/tmp/unimem-block-access-validation-6eQqO1'
    let original = (open ($root | path join 'receipts/candidate/semver-parent/result.json'))
    let logs = ($root | path join 'receipts/candidate/semver-parent-unimem')
    if ($logs | path exists) { error make {msg: 'receipt already exists'} }
    mkdir $logs
    let command = ($original.command | update directory ($root | path join 'candidate/honeycrisp/unimem') | update arguments ['run', '1.95.0', 'cargo', 'semver-checks', '--manifest-path', ($root | path join 'candidate/honeycrisp/unimem/Cargo.toml'), '-p', 'unimem', '--baseline-root', ($root | path join 'parent/honeycrisp/unimem'), '--verbose'])
    $command | to nuon | save ($logs | path join command.nuon)
    $original.resolved_tools | to json | save ($logs | path join resolved-tools.json)
    let tool = (which cargo-semver-checks | first | get path)
    {path: $tool, sha256: (open --raw $tool | hash sha256), version: (run-external $tool '--version' | complete)} | to json | save ($logs | path join semver-tool.json)
    let started = (date now)
    cd $command.directory
    let result = (with-env $command.environment { run-external $command.program ...$command.arguments | complete })
    let finished = (date now)
    $result.stdout | save ($logs | path join stdout)
    $result.stderr | save ($logs | path join stderr)
    $result.exit_code | into string | save ($logs | path join exit)
    let lock_after = (open --raw ($root | path join 'candidate/honeycrisp/Cargo.lock') | hash sha256)
    ($original | update gate 'semver-parent-unimem' | update label 'semver-parent-unimem' | update command $command | update started ($started | format date '%+') | update finished ($finished | format date '%+') | update exit_code $result.exit_code | update lock_after $lock_after | update lock_unchanged ($lock_after == $original.lock_before) | update runner_sha256 (open --raw $env.CURRENT_FILE | hash sha256)) | to json | save ($logs | path join result.json)
    print {exit: $result.exit_code, logs: $logs}
}
