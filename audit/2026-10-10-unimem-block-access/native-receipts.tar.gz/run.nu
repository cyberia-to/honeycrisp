# Run only after the parent explicitly authorizes implementation/gates.
# Every invocation creates a fresh receipt; no old result is overwritten.
def main [suite: string, gate: string, --label: string] {
    let root = $env.FILE_PWD
    let runner_sha256 = (open --raw ($root | path join 'run.nu') | hash sha256)
    if $suite not-in ['parent', 'candidate'] { error make {msg: 'suite must be parent or candidate'} }
    if $suite == 'candidate' and not ($root | path join 'overlay.json' | path exists) { error make {msg: 'candidate requires an explicitly frozen overlay first'} }
    let nightly = ($gate == 'nightly-doc')
    let toolchain = (if $nightly { 'nightly-2025-11-26' } else { '1.95.0' })
    let compiler = (open ($root | path join 'toolchains.json') | get compilers | where name == $toolchain | first)
    if $compiler.rustc.exit_code != 0 or $compiler.rustdoc.exit_code != 0 { error make {msg: 'recorded compiler unavailable'} }
    let workdir = ($root | path join $suite 'honeycrisp')
    let target = ($root | path join 'target' $suite)
    let arguments = (match $gate {
        'fmt' => ['fmt', '--all', '--', '--check'],
        'clippy' => ['clippy', '--workspace', '--all-targets', '--locked', '--', '-D', 'warnings'],
        'clippy-owned' => ['clippy', '-p', 'unimem', '-p', 'aruminium', '--all-targets', '--locked', '--offline', '--', '-D', 'warnings'],
        'clippy-owned-nodeps' => ['clippy', '-p', 'unimem', '-p', 'aruminium', '--no-deps', '--all-targets', '--locked', '--offline', '--', '-D', 'warnings'],
        'clippy-warnings' => ['clippy', '--workspace', '--all-targets', '--locked', '--offline', '--message-format=json', '--', '-W', 'warnings'],
        'clippy-owned-lib' => ['clippy', '-p', 'unimem', '-p', 'aruminium', '--lib', '--no-deps', '--locked', '--offline', '--', '-D', 'warnings', '-D', 'clippy::missing_safety_doc'],
        'clippy-fixtures-warnings' => ['clippy', '-p', 'unimem', '-p', 'aruminium', '-p', 'rane', '--tests', '--no-deps', '--locked', '--offline', '--message-format=json', '--', '-W', 'warnings'],
        'release' => ['build', '--release', '--workspace', '--locked'],
        'tests' => ['test', '--workspace', '--locked'],
        'unimem-release' => ['test', '-p', 'unimem', '--release', '--locked'],
        'gpu-block' => ['test', '-p', 'aruminium', '--test', 'integration', 'wrap_block_vecadd', '--locked'],
        'gpu-raw' => ['test', '-p', 'aruminium', '--test', 'integration', 'gpu_buffer_wrap', '--locked'],
        'ane' => ['test', '-p', 'rane', '--test', 'hardware', 'run_direct_with_unimem_block', '--locked'],
        'unimem-build' => ['build', '-p', 'unimem', '--locked'],
        'unimem-bench' => ['bench', '-p', 'unimem', '--locked'],
        'pipeline' => ['run', '-p', 'unimem', '--example', 'pipeline', '--release', '--locked'],
        'gpu-example' => ['run', '-p', 'aruminium', '--example', 'vecadd', '--locked', '--offline'],
        'ane-example' => ['run', '-p', 'rane', '--example', 'matmul', '--locked', '--offline'],
        'docs' => ['doc', '-p', 'unimem', '-p', 'aruminium', '--no-deps', '--locked'],
        'nightly-doc' => ['test', '-p', 'unimem', '-p', 'aruminium', '--doc', '--locked'],
        'semver-parent' => ['semver-checks', '--workspace', '--exclude', 'metal-benches', '--exclude', 'rane-benches', '--baseline-root', ($root | path join 'parent/honeycrisp'), '--verbose'],
        _ => { error make {msg: $"unknown gate: ($gate)"} }
    })
    let label = (if $label == null { $gate } else { $label })
    if $label !~ '^[a-z0-9][a-z0-9_-]*$' { error make {msg: 'receipt label must contain only lowercase letters, digits, underscore or hyphen'} }
    let logs = ($root | path join 'receipts' $suite $label)
    if ($logs | path exists) { error make {msg: 'receipt already exists; use a new label'} }
    mkdir $logs
    let toolchain_bin = ($compiler.rustc.stdout | str trim | path dirname)
    let environment = {
        CARGO_TARGET_DIR: $target, CARGO_NET_OFFLINE: 'true', RUSTUP_TOOLCHAIN: $toolchain,
        CARGO_BUILD_JOBS: '4', PATH: ([$toolchain_bin] | append $env.PATH),
        RUSTC: ($compiler.rustc.stdout | str trim), RUSTDOC: ($compiler.rustdoc.stdout | str trim),
        RUSTDOCFLAGS: (if $gate == 'docs' { '-Dwarnings' } else { '' })
    }
    let command_args = (['run', $toolchain, 'cargo'] | append $arguments)
    let command = {directory: $workdir, program: rustup, arguments: $command_args, environment: $environment}
    $command | to nuon | save ($logs | path join 'command.nuon')
    let tool_names = (if $nightly { ['cargo', 'rustc', 'rustdoc'] } else { ['cargo', 'rustc', 'rustdoc', 'cargo-clippy', 'clippy-driver', 'cargo-fmt', 'rustfmt'] })
    let resolved_tools = (with-env $environment {
        $tool_names | each {|name|
            let path = (which $name | first | get path)
            if ($path | path dirname) != $toolchain_bin { error make {msg: $"unexpected ($name) path: ($path)"} }
            let observed = (run-external $path '--version' | complete)
            {name: $name, path: $path, sha256: (open --raw $path | hash sha256), version: $observed}
        }
    })
    $resolved_tools | to json | save ($logs | path join 'resolved-tools.json')
    let prepared = (open ($root | path join 'prepared.json'))
    let overlay = (if $suite == 'candidate' { open ($root | path join 'overlay.json') } else { null })
    let started = (date now)
    cd $workdir
    let result = (with-env $environment { run-external 'rustup' ...$command_args | complete })
    let finished = (date now)
    $result.stdout | save ($logs | path join 'stdout')
    $result.stderr | save ($logs | path join 'stderr')
    $result.exit_code | into string | save ($logs | path join 'exit')
    let lock_before = ($prepared.sources | where name == 'honeycrisp' | first | get lock_sha256)
    let lock_after = (open --raw ($workdir | path join 'Cargo.lock') | hash sha256)
    {
        suite: $suite, gate: $gate, label: $label,
        started: ($started | format date '%+'), finished: ($finished | format date '%+'),
        exit_code: $result.exit_code, command: $command, sources: $prepared.sources,
        overlay: $overlay, compiler: $compiler,
        resolved_tools: $resolved_tools,
        runner_sha256: $runner_sha256,
        toolchain_metadata_sha256: (open --raw ($root | path join 'toolchains.json') | hash sha256),
        lock_before: $lock_before, lock_after: $lock_after, lock_unchanged: ($lock_after == $lock_before)
    } | to json | save ($logs | path join 'result.json')
    print $"($suite)/($label): exit ($result.exit_code); receipt ($logs)"
    if $lock_after != $lock_before { error make {msg: 'gate altered the preserved Cargo.lock; actual gate exit remains in receipt'} }
    exit $result.exit_code
}
