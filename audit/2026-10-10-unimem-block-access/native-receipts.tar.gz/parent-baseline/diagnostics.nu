def normalized [root: string, suite: string, label: string] {
    let log = ($root | path join receipts $suite $label)
    let result = (open ($log | path join result.json))
    let messages = (open --raw ($log | path join stdout) | lines | each {|line| $line | from json } | where reason == compiler-message)
    let records = ($messages | each {|r|
        {
            package: ($r.package_id | str replace $"path+file:///private($root)/($suite)/honeycrisp/" '' | str replace $"path+file://($root)/($suite)/honeycrisp/" ''),
            target: $r.target.name, kind: $r.target.kind, level: $r.message.level,
            code: ($r.message.code.code? | default ''), message: $r.message.message,
            spans: ($r.message.spans | each {|s| {file: $s.file_name, line: $s.line_start, column: $s.column_start, primary: $s.is_primary, label: $s.label, text: ($s.text | get text)}}),
            children: ($r.message.children | each {|c| {level: $c.level, message: $c.message}})
        }
    })
    let keys = ($records | each {|r|
        $r | update spans {|row| $row.spans | reject line column } | to json --raw
    } | sort | uniq --count | each { to json --raw })
    {result: $result, records: $records, keys: $keys}
}

def main [root: string, suite: string, label: string, --compare: string] {
    let actual = (normalized $root $suite $label)
    let out = ($root | path join receipts $suite $label)
    $actual.records | to json | save --force ($out | path join diagnostics.json)
    $actual.keys | to json | save --force ($out | path join diagnostic-keys.json)
    let counts = ($actual.records | group-by level | transpose level records | each {|r| {level: $r.level, count: ($r.records | length)}})
    let summary = {suite: $suite, label: $label, exit: $actual.result.exit_code, diagnostic_counts: $counts, counted_keys: ($actual.keys | length)}
    $summary | to json | save --force ($out | path join diagnostic-summary.json)
    if $compare != null {
        let parent = (normalized $root parent $compare)
        {
            parent: $compare, candidate: $label, parent_exit: $parent.result.exit_code, candidate_exit: $actual.result.exit_code,
            note: 'Complete emitted message multisets; a failed invocation is not proof that all target units were linted. Line/column shifts are excluded from keys, duplicate counts, primary source text and child messages are retained. Inspect each difference and raw receipts.',
            added: ($actual.keys | where {|x| $x not-in $parent.keys}),
            removed: ($parent.keys | where {|x| $x not-in $actual.keys})
        } | to json | save --force ($out | path join diagnostic-comparison.json)
    }
    $summary | to json | print
}
