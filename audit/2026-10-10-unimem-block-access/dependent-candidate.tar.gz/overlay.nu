def main [source: string, manifest: string] {
 let root = $env.FILE_PWD
 if ($root | path join overlay.json | path exists) { error make {msg: 'new freeze requires new candidate snapshot'} }
 let permitted = (open --raw /tmp/unimem-block-access-validation-6eQqO1/overlay-paths.txt | lines)
 if ($permitted | length) != 16 { error make {msg: 'unexpected scope'} }
 let files = (open --raw $manifest | lines | parse '{sha256}  {path}')
 if ($files | is-empty) or (($files | get path | uniq | length) != ($files | length)) { error make {msg: 'empty or repeated overlay paths'} }
 for row in $files {
  if $row.path not-in $permitted { error make {msg: $'out of scope: ($row.path)'} }
  if (open --raw ($source | path join $row.path) | hash sha256) != $row.sha256 { error make {msg: 'source hash drift'} }
 }
 let scenarios = (open ($root | path join scenarios.json) | where honeycrisp_dependency == true)
 for scenario in $scenarios {
  let destination_root = ($scenario.cwd | path dirname | path join honeycrisp)
  for row in $files {
   let destination = ($destination_root | path join $row.path)
   mkdir ($destination | path dirname)
   cp ($source | path join $row.path) $destination
   if (open --raw $destination | hash sha256) != $row.sha256 { error make {msg: 'copied bytes mismatch'} }
  }
 }
 {classification: 'local candidate API diagnostic overlay; not release input', source: $source, manifest: $manifest, manifest_sha256: (open --raw $manifest | hash sha256), files: $files, applied_at: (date now), scenarios: ($scenarios | get repo)} | to json | save ($root | path join overlay.json)
 print {scenarios: ($scenarios | length), paths: ($files | length)}
}
