let root = $env.FILE_PWD
let prior = (open /tmp/unimem-dependent-baseline.cX82Mt/tool-environment.json)
mut rows = []
for tool in $prior.tools {
 mut binaries = []
 for name in [cargo rustc rustdoc] {
  let path = ($tool | get $name)
  let args = if $name == rustc { ['-Vv'] } else { ['-V'] }
  let got = (run-external $path ...$args | complete)
  let expected = ($tool | get $'($name)_version')
  if $got != $expected { error make {msg: $'tool version differs: ($path)'} }
  let hash = (^shasum -a 256 $path | split row ' ' | first)
  $binaries = ($binaries | append {name: $name, path: $path, sha256: $hash, version: $got})
 }
 $rows = ($rows | append {toolchain: $tool.toolchain, binaries: $binaries})
}
mut inherited = {}
for name in [RUSTFLAGS RUSTDOCFLAGS RUSTC_WRAPPER CARGO_ENCODED_RUSTFLAGS RUSTC_BOOTSTRAP CARGO_HOME] {
 let value = ($env | get -o $name)
 if $value != ($prior.inherited | get $name) { error make {msg: $'inherited environment changed: ($name)'} }
 $inherited = ($inherited | insert $name $value)
}
{tools: $rows, inherited: $inherited, recorded: (date now), baseline_versions_equal: true} | to json | save ($root | path join toolchains.json)
print {toolchains_verified: ($rows | length), build_or_test_run: false}
