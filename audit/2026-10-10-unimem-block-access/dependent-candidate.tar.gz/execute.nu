def main [] {
 let root = $env.FILE_PWD
 if not ($root | path join overlay.json | path exists) { error make {msg: 'no candidate source overlay'} }
 for item in (open ($root | path join selected-commands.json)) {
  let receipt = ($root | path join logs $item.repo $'($item.label).json')
  if ($receipt | path exists) { error make {msg: 'partial execution exists: explicitly select remaining commands after inspecting receipts'} }
  let got = (^nu ($root | path join run.nu) $item.repo $item.label --args ($item.args | to json --raw) | complete)
  print $got.stdout
  if $got.exit_code != 0 { error make {msg: $'runner failed: ($got.stderr)'} }
 }
}
