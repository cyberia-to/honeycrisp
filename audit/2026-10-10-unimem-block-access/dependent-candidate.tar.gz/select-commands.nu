let root = $env.FILE_PWD
let baseline = '/tmp/unimem-dependent-baseline.cX82Mt'
let allowed = (open ($root | path join scenarios.json) | where honeycrisp_dependency == true | get repo)
mut selected = []
for command in (open ($baseline | path join commands.json)) {
 if $command.repo not-in $allowed or '--locked' not-in $command.args or '--offline' not-in $command.args or ($command.args | first) in [fetch generate-lockfile] { continue }
 let key = ($command.repo + '::' + ($command.args | to json --raw))
 $selected = ($selected | where {|row| $row.key != $key} | append {key: $key, repo: $command.repo, label: $command.label, args: $command.args, baseline_receipt: ($baseline | path join logs $command.repo $'($command.label).json'), baseline_exit: $command.exit_code})
}
$selected | to json | save ($root | path join selected-commands.json)
print {commands: ($selected | length), scenarios: ($selected | get repo | uniq | length), excludes: 'fetch/resolution, repeated pre-cache commands, unchanged nox closure'}
