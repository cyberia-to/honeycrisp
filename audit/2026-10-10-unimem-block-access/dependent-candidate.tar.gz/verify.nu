def digest [path: string] { open --raw $path | hash sha256 }
def diag [path: string] {
 let body = (open --raw $path)
 {errors: ($body | lines | where {|line| $line =~ '^error'}), warnings: ($body | lines | where {|line| $line =~ '^warning'}), sites: ($body | lines | where {|line| $line =~ '^\s*--> '}), test_results: ($body | lines | where {|line| $line =~ '^test result:'})}
}
def main [] {
 let root = $env.FILE_PWD
 let baseline = '/tmp/unimem-dependent-baseline.cX82Mt'
 let baseline_check = (do { cd $baseline; ^shasum -a 256 -c SHA256SUMS | complete })
 if $baseline_check.exit_code != 0 { error make {msg: 'baseline manifest drift'} }
 let overlay = (open ($root | path join overlay.json))
 let overlay_sha = (digest ($root | path join overlay.json))
 mut rows = []
 for selected in (open ($root | path join selected-commands.json)) {
  let stem = ($root | path join logs $selected.repo $selected.label)
  let receipt = (open $'($stem).json')
  let base = (open $selected.baseline_receipt)
  if $receipt.args != $base.args or $receipt.args != $selected.args { error make {msg: 'command drift'} }
  if $receipt.lock_before != $receipt.lock_after or $receipt.lock_before != $base.lock_after { error make {msg: 'lock drift'} }
  if $receipt.overlay_sha256 != $overlay_sha { error make {msg: 'overlay drift'} }
  for stream in [stdout stderr] {
   if (digest $'($stem).($stream)') != ($receipt | get $'($stream)_sha256') { error make {msg: 'candidate log drift'} }
  }
  let stdout = (open --raw $'($stem).stdout')
  let metadata = ($selected.args | first) == 'metadata' and $receipt.exit_code == 0
  let local_packages = if $metadata {
   let data = ($stdout | from json)
   $data.packages | where source == null | each {|p|
    let manifest = ($p.manifest_path | path expand)
    let source = ($root | path join scenarios $selected.repo source | path expand)
    if not ($manifest | str starts-with $'($source)/') { error make {msg: $'escaped local dependency: ($manifest)'} }
    {name: $p.name, manifest: $manifest}
   }
  } else { [] }
  $rows = ($rows | append {repo: $selected.repo, label: $selected.label, args: $selected.args, baseline_receipt: $selected.baseline_receipt, candidate_receipt: $'($stem).json', parent_exit: $base.exit_code, candidate_exit: $receipt.exit_code, parent: (diag ($selected.baseline_receipt | str replace '.json' '.stderr')), candidate: (diag $'($stem).stderr'), parent_tests: ((diag ($selected.baseline_receipt | str replace '.json' '.stdout')).test_results), candidate_tests: ((diag $'($stem).stdout').test_results), local_packages: $local_packages})
 }
 $rows | to json | save ($root | path join comparison.json)
 mut sources = []
 for scenario in (open ($root | path join scenarios.json)) {
  let source = ($scenario.cwd | path dirname)
  let baseline = ($scenario.baseline_cwd | path dirname)
  let difference = (^diff -qr $baseline $source | complete)
  if $difference.exit_code not-in [0 1] { error make {msg: 'source comparison failed'} }
  mut changed = []
  for line in ($difference.stdout | lines) {
   if ($line | str starts-with 'Files ') {
    let right = ($line | split row ' and ' | last | str replace --regex ' differ$' '')
    $changed = ($changed | append ($right | path relative-to ($source | path join honeycrisp)))
   } else if ($line | str starts-with $'Only in ($source)/honeycrisp/') {
    let parts = ($line | str replace 'Only in ' '' | split row ': ')
    let extra = ($parts.0 | path join $parts.1)
    let files = if ($extra | path type) == dir { (glob $'($extra)/**/*' | where {|p| ($p | path type) == file}) } else { [$extra] }
    $changed = ($changed | append ($files | each {|p| $p | path relative-to ($source | path join honeycrisp)}))
   } else { error make {msg: $'unexpected source difference: ($line)'} }
  }
  if $scenario.honeycrisp_dependency {
   if ($changed | sort) != ($overlay.files.path | sort) { error make {msg: 'source whitelist mismatch'} }
   for item in $overlay.files {
    if (digest ($source | path join honeycrisp $item.path)) != $item.sha256 { error make {msg: 'final source freeze mismatch'} }
   }
  } else if ($changed | length) != 0 { error make {msg: 'unrelated scenario drift'} }
  $sources = ($sources | append {repo: $scenario.repo, diff_exit: $difference.exit_code, changed: $changed, stdout: $difference.stdout, stderr: $difference.stderr})
 }
 $sources | to json | save ($root | path join final-source-comparison.json)
 {commands: ($rows | length), green: ($rows | where candidate_exit == 0 | length), red: ($rows | where candidate_exit != 0 | length), scenarios: ($sources | length), overlay_sha256: $overlay_sha, source_manifest: $overlay.manifest_sha256, command_lock_and_log_checks: true, local_metadata_paths_confined: true, source_diff_whitelist_checked: true} | to json | save ($root | path join verification.json)
 $rows | select repo label parent_exit candidate_exit | table -e
}
