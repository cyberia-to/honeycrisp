def --wrapped checked [...args: string] {
 let got = (run-external ($args | first) ...($args | skip 1) | complete)
 if $got.exit_code != 0 { error make {msg: $'failed ($args | to nuon): ($got.stderr)'} }
 $got.stdout
}
def main [] {
 let root = $env.FILE_PWD
 let baseline = '/tmp/unimem-dependent-baseline.cX82Mt'
 if ($root | path join scenarios | path exists) { error make {msg: 'refuse replace prepared inputs'} }
 let archives = (open /tmp/unimem-access-origins.knYGlE/archives.json)
 let locks = (open ($baseline | path join retained-locks manifest.json))
 let base_scenarios = (open ($baseline | path join scenarios.json))
 let verification = (do { cd $baseline; ^shasum -a 256 -c SHA256SUMS | complete })
 $verification.stdout | save ($root | path join baseline-integrity.stdout)
 $verification.stderr | save ($root | path join baseline-integrity.stderr)
 if $verification.exit_code != 0 { error make {msg: 'baseline manifest failed'} }
 mut rows = []
 for source in $base_scenarios {
  let scenario = ($root | path join scenarios $source.repo source)
  mkdir $scenario
  for pin in $source.inputs {
   let archive = ($archives | where repo == $pin.repo | first)
   if $archive.pin != $pin.pin or $archive.sha256 != $pin.sha256 { error make {msg: 'catalogue pin mismatch'} }
   if (open --raw $archive.archive | hash sha256) != $pin.sha256 { error make {msg: 'archive bytes mismatch'} }
   let destination = ($scenario | path join $pin.repo)
   mkdir $destination
   checked tar -xf $archive.archive -C $destination | ignore
  }
  let cwd = ($root | path join ($source.cwd | path relative-to $baseline))
  let local = ($source.repo | str ends-with '-localresolved')
  if $local {
   let name = ($source.repo | str replace '-localresolved' '')
   let lock = ($locks | where repo == $name | first)
   if (open --raw $lock.path | hash sha256) != $lock.sha256 { error make {msg: 'retained lock drift'} }
   cp $lock.path ($cwd | path join Cargo.lock)
  }
  let comparison = (^diff -qr $scenario ($source.cwd | path dirname) | complete)
  if $comparison.exit_code != 0 { error make {msg: $'prepared source differs from baseline: ($comparison.stdout) ($comparison.stderr)'} }
  $rows = ($rows | append {repo: $source.repo, cwd: $cwd, baseline_cwd: $source.cwd, inputs: $source.inputs, local_resolved: $local, honeycrisp_dependency: ('honeycrisp' in ($source.inputs | get repo)), prepared_equal_to_baseline: true})
 }
 $rows | to json | save ($root | path join scenarios.json)
 {recorded: (date now), baseline: $baseline, baseline_manifest_sha256: (open --raw ($baseline | path join SHA256SUMS) | hash sha256), sources_count: ($rows | length), overlay: null, cargo_invoked: false, source_state: 'Exact committed baseline archives plus five identical retained local diagnostic locks; no new dependency resolution. Nox closure excludes honeycrisp and will reuse unchanged baseline evidence.'} | to json | save ($root | path join preparation.json)
 print {scenarios: ($rows | length), candidate_overlay: false, cargo_invoked: false}
}
