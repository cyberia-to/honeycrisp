def lock-state [cwd: path] {
 let path = ($cwd | path join Cargo.lock)
 if ($path | path exists) { {exists: true, sha256: (open --raw $path | hash sha256)} } else { {exists: false, sha256: null} }
}
def usage [root: path] { ^du -sk $root | parse -r '^(?P<kb>\d+)\s+' | get 0.kb | into int | $in * 1024 }
def main [repo: string, label: string, --args: string] {
 let root = $env.FILE_PWD
 if not ($root | path join overlay.json | path exists) { error make {msg: 'candidate overlay freeze required'} }
 let overlay = (open ($root | path join overlay.json))
 let scenario = (open ($root | path join scenarios.json) | where repo == $repo | first)
 if not $scenario.honeycrisp_dependency { error make {msg: 'unaffected scenario: reuse baseline instead'} }
 for item in $overlay.files {
  let path = ($scenario.cwd | path dirname | path join honeycrisp $item.path)
  if (open --raw $path | hash sha256) != $item.sha256 { error make {msg: $'overlay drift: ($path)'} }
 }
 let toolchain = if $repo == nika { 'nightly-2025-11-26' } else { '1.95.0' }
 let bin = $'/Users/master/.rustup/toolchains/($toolchain)-aarch64-apple-darwin/bin'
 let cargo = ($bin | path join cargo)
 let target = ($root | path join targets $repo)
 let environment = {PATH: ([$bin] | append $env.PATH), RUSTC: ($bin | path join rustc), RUSTDOC: ($bin | path join rustdoc), RUSTUP_TOOLCHAIN: $toolchain, RUSTUP_AUTO_INSTALL: '0', CARGO_TARGET_DIR: $target, CARGO_BUILD_JOBS: '2', CARGO_INCREMENTAL: '0'}
 let environment = if $label in [build-release-bootstrap difftest-bootstrap] { $environment | insert RUSTC_BOOTSTRAP '1' } else { $environment }
 let argv = ($args | from json)
 if '--locked' not-in $argv or '--offline' not-in $argv { error make {msg: 'same retained lock/offline required'} }
 let logs = ($root | path join logs $repo)
 mkdir $logs
 let receipt = ($logs | path join $'($label).json')
 if ($receipt | path exists) { error make {msg: 'refuse receipt overwrite'} }
 let size_before = (usage $root)
 if $size_before >= 20000000000 { error make {msg: '20GB staging threshold before next gate'} }
 let before = (lock-state $scenario.cwd)
 let started = (date now)
 let result = (with-env $environment { cd $scenario.cwd; run-external $cargo ...$argv | complete })
 let ended = (date now)
 let after = (lock-state $scenario.cwd)
 let size_after = (usage $root)
 $result.stdout | save ($logs | path join $'($label).stdout')
 $result.stderr | save ($logs | path join $'($label).stderr')
 {repo: $repo, label: $label, cwd: $scenario.cwd, command: $cargo, args: $argv, environment: $environment, start: $started, end: $ended, exit_code: $result.exit_code, lock_before: $before, lock_after: $after, overlay_sha256: (open --raw ($root | path join overlay.json) | hash sha256), stdout_sha256: ($result.stdout | hash sha256), stderr_sha256: ($result.stderr | hash sha256), bytes_before: $size_before, bytes_after: $size_after} | to json | save $receipt
 if $before != $after { error make {msg: 'lock drift; raw receipts retained'} }
 if $size_after > 30000000000 { error make {msg: '30GB total limit exceeded'} }
 print {repo: $repo, label: $label, cargo_exit: $result.exit_code}
}
