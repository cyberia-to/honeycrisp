def check [condition: bool, message: string] {
    if not $condition { error make {msg: $message} }
}
def main [pack: path = '.', --output: path, --git] {
    let pack = ($pack | path expand)
    let support = ($pack | path join support)
    let m = (open ($pack | path join manifest.json))
    let sections = (open ($pack | path join sections.json))
    let files = (open ($pack | path join support-files.json))
    check ((open --raw ($pack | path join sections.json) | hash sha256) == $m.sections_sha256) 'section index'
    check ((open --raw ($pack | path join support-files.json) | hash sha256) == $m.support_sha256) 'support index'
    check ((open --raw ($pack | path join footer.txt) | hash sha256) == $m.footer_sha256) 'footer'
    for r in $files {
        let b = (open --raw ($pack | path join $r.path) | into binary)
        check (($b | hash sha256) == $r.sha256 and ($b | bytes length) == $r.bytes) $'support ($r.path)'
    }
    mut chunks = []
    for pair in ($sections | enumerate) {
        let r = $pair.item
        let source = (open --raw ($support | path join $r.path) | into binary)
        let b = ($source | bytes at $r.byte_offset..<($r.byte_offset + $r.bytes))
        check (($source | hash sha256) == $r.source_sha256 and ($source | bytes length) == $r.source_bytes and ($b | hash sha256) == $r.sha256 and ($b | bytes length) == $r.bytes) 'exact section or excerpt'
        $chunks = ($chunks | append $"\n===== ($pair.index + 1). ($r.label) | ($r.path) @($r.byte_offset)+($r.bytes) SHA256 ($r.sha256) =====\n" | append ($b | decode utf-8) | append "\n")
    }
    let rebuilt = ($chunks | append (open --raw ($pack | path join footer.txt)) | str join | into binary)
    check (($rebuilt | hash sha256) == $m.review_sha256 and ($rebuilt | bytes length) == $m.review_bytes and $rebuilt == (open --raw ($pack | path join review.txt) | into binary)) 'exact review reconstruction'
    check (($sections | length) == $m.sections and ($files | length) == $m.support_files) 'index counts'
    let sources = (open ($support | path join sources.json))
    let tag = (open ($support | path join tag.json))
    let epochs = ($sources | append {name: tag, revision: $tag.revision, repository: $tag.repository, archive_sha256: $tag.archive_sha256, files: $tag.files})
    let scratch = (^mktemp -d -t unimem-plan-verify | str trim)
    mut source_count = 0
    for s in $epochs {
        let tar = ($support | path join $'($s.name).tar')
        check ((open --raw $tar | hash sha256) == $s.archive_sha256) 'source archive hash'
        let dest = ($scratch | path join $s.name)
        mkdir $dest
        let extracted = (^tar -xf $tar -C $dest | complete)
        check ($extracted.exit_code == 0) 'source extraction'
        for f in $s.files {
            let p = ($dest | path join $f.path)
            let b = (open --raw $p | into binary)
            check (($b | hash sha256) == $f.sha256 and ($b | bytes length) == ($f.bytes | into int) and ($b | ^git hash-object --stdin | str trim) == $f.blob and (^stat -f '%Lp' $p | str trim) == ($f.mode | str substring 3..)) $'Git export ($s.name)/($f.path)'
            $source_count = $source_count + 1
            if $s.name == honeycrisp and (($support | path join parent $f.path) | path exists) {
                check ((open --raw ($support | path join parent $f.path) | hash sha256) == $f.sha256) $'owning source ($f.path)'
            }
        }
        if $git {
            let actual = (^git -C $s.repository ls-tree -rl $s.revision | complete)
            check ($actual.exit_code == 0) 'actual Git revision available'
            let rows = ($actual.stdout | lines | parse --regex '^(?P<mode>\S+) (?P<kind>\S+) (?P<blob>\S+) +(?P<bytes>\d+)\t(?P<path>.*)$' | select path mode blob)
            check ($rows == ($s.files | select path mode blob)) 'exact revision tree membership'
        }
    }
    let lock = (open --raw ($support | path join parent Cargo.lock) | from toml | get package)
    let acquisition = (open ($support | path join registry-acquisition.json))
    mut primary_count = 0
    for r in $acquisition {
        let expected = ($lock | where name == $r.name and version == $r.version)
        check (($expected | length) == 1 and ($expected | first | get checksum) == $r.package_sha256 and $r.exit_code == 0) 'official registry lock identity'
        let primary = ($support | path join primary $'($r.name)-($r.version)')
        if ($primary | path exists) {
            for f in ($r.files | transpose path sha256) {
                check ((open --raw ($primary | path join $f.path) | hash sha256) == $f.sha256) 'primary package body'
                $primary_count = $primary_count + 1
            }
        }
    }
    let source_hash = (open --raw ($support | path join sources.json) | hash sha256)
    let runner_hash = (open --raw ($support | path join run.nu) | hash sha256)
    let exits = [101 0 0 101 0 0 0 1 1 101 0 101 0 0 0 101 101]
    let receipts = (glob ($support | path join records '*' receipt.json) | sort)
    check (($receipts | length) == 17) 'numbered record count'
    for pair in ($receipts | enumerate) {
        let p = $pair.item
        let r = (open $p)
        check ($r.exit_code == ($exits | get $pair.index) and $r.runner_sha256 == $runner_hash and $r.source_manifest_sha256 == $source_hash) 'numbered record identity/outcome'
        for stream in [stdout stderr] {
            let b = (open --raw ($p | path dirname | path join $stream) | into binary)
            let expected = ($r | get $stream)
            check (($b | hash sha256) == $expected.sha256 and ($b | bytes length) == $expected.bytes) 'raw numbered stream'
        }
    }
    for name in [durable-parent-v1 durable-drift-v1] {
        let r = (open ($support | path join $name receipt.json))
        for stream in [stdout stderr] {
            check ((open --raw ($support | path join $name $stream) | hash sha256) == ($r | get $'($stream)_sha256')) 'raw durable stream'
        }
    }
    check ((open ($support | path join durable-parent-v1 receipt.json)).gate_sha256 == (open --raw ($support | path join proposed scripts check-no-std.nu) | hash sha256)) 'exact measured gate'
    for c in (open ($support | path join consumer-inputs.json)) {
        for f in $c.files { check ((open --raw ($support | path join $'consumer-($c.kind)-parent' $f.path) | hash sha256) == $f.sha256) 'frozen consumer input' }
    }
    for p in [block_access.rs block_creation.rs roundtrip.rs] {
        check ((open --raw ($support | path join parent unimem tests $p)) == (open --raw ($support | path join consumer-native-parent tests $p))) 'native test body parity'
    }
    check ((open --raw ($support | path join proposed fixtures no-std consumer.rs)) == (open --raw ($support | path join consumer-frozen src main.rs))) 'literal no_std witness parity'
    for name in [03-parent-native 06-parent-isolated-native] {
        let counts = (open --raw ($support | path join records $name stdout) | lines | parse --regex '^test result: ok\. (?P<passed>\d+) passed; (?P<failed>\d+) failed; (?P<ignored>\d+) ignored;')
        let expected = (if $name == '03-parent-native' { 66 } else { 44 })
        check (($counts.passed | into int | math sum) == $expected and ($counts.failed | into int | math sum) == 0) 'actual native test counts'
    }
    check ((open --raw ($support | path join records 04-parent-no-std-consumer stderr) | str contains 'error[E0152]') and (open --raw ($support | path join durable-parent-v1 stderr) | str contains 'error[E0152]')) 'parent discriminator'
    check (open --raw ($support | path join durable-drift-v1 stderr) | str contains 'no_std fixture dependency drift: crossbeam-queue') 'drift discriminator'
    rm -r $scratch
    let result = {status: PASS, parent: $m.parent, review_bytes: $m.review_bytes, review_sha256: $m.review_sha256, sections: $m.sections, support_files: $m.support_files, source_entries: $source_count, actual_git_membership: $git, primary_files: $primary_count, official_archives: ($acquisition | length), numbered_records: 17, numbered_streams: 34, durable_records: 2, durable_streams: 4}
    if $output != null { $result | to json | save $output }
    print ($result | to json)
}
