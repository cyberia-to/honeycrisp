let root = '/tmp/unimem-core-research'
let output = ($root | path join inventory)
mkdir $output
let entries = [
    {name: honeycrisp, repo: '/Users/master/cyber/honeycrisp-unimem-core', rev: '9cbd48070a136e24711896c930670fcff8a147fc'},
    {name: strata, repo: '/Users/master/cyber/strata', rev: '494df7a0973ae10a6cc1c2022e644d70449a29d6'},
    {name: nox, repo: '/Users/master/cyber/nox', rev: '7fe9ad368dc93ef136c196c2366b39f1c67e1cd7'},
    {name: erga, repo: '/Users/master/cyber/erga', rev: 'eea9bb5c6ffacecc6a18bad78ee61c07519f5ef6'},
    {name: cyb, repo: '/Users/master/cyber/cyb', rev: '4e4711f1ba4de640e60e29304b6180c94f20c9d7'},
    {name: kadek, repo: '/Users/master/cyber/kadek', rev: '43165457fb681cee1c23b4450d7590bb123a3df5'},
    {name: soft3, repo: '/Users/master/cyber/soft3', rev: '2661a79db1df4c2c3881f98462332bf2641f5c68'}
]
mut result = []
for e in $entries {
    let argv = ['git' '-C' $e.repo 'grep' '-n' '-E' 'honeycrisp|unimem|acpu|rane|aruminium' $e.rev '--' '*Cargo.toml']
    let started = (date now | format date '%+')
    let raw = (^($argv.0) ...($argv | skip 1) | complete)
    let paths = ($raw.stdout | lines | parse --regex '^[^:]+:(?P<path>[^:]+):' | get path | uniq)
    mut files = []
    for p in $paths {
        let text = (^git -C $e.repo show $'($e.rev):($p)' | complete)
        if $text.exit_code != 0 { error make {msg: $text.stderr} }
        let dest = ($output | path join $e.name $'($p).txt')
        mkdir ($dest | path dirname)
        $text.stdout | save --raw $dest
        $files = ($files | append {path: $p, saved: ($dest | path relative-to $root), sha256: ($text.stdout | hash sha256), bytes: ($text.stdout | into binary | bytes length)})
    }
    $result = ($result | append ($e | insert argv $argv | insert started $started | insert finished (date now | format date '%+') | insert result $raw | insert files $files))
}
$result | to json | save ($output | path join manifests.json)
^git -C /Users/master/cyber/soft3 show '2661a79db1df4c2c3881f98462332bf2641f5c68:release/components.toml' | save --raw ($output | path join components.toml.txt)
mut primary = []
for name in ['crossbeam-queue-0.3.12' 'crossbeam-utils-0.8.21' 'mutants-0.0.3'] {
    let verified = ($root | path join registry $name)
    let cached = ($root | path join primary $name)
    let checksums = (open ($verified | path join .cargo-checksum.json))
    for row in ($checksums.files | transpose path sha256) {
        if (open --raw ($verified | path join $row.path) | hash sha256) != $row.sha256 or (open --raw ($cached | path join $row.path) | hash sha256) != $row.sha256 { error make {msg: 'primary source mismatch'} }
    }
    $primary = ($primary | append {package: $name, files: ($checksums.files | columns | length), archive_sha256: $checksums.package, cached_body_parity: true})
}
$primary | to json | save ($output | path join primary-parity.json)
print {consumer_manifest_files: ($result.files | flatten | length), primary: $primary}
