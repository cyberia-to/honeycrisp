fn main() { let plan = unimem::Block::plan(1).unwrap(); assert!(plan.allocation_size() >= 1); }
