let root = '/tmp/unimem-core-research'
let dest = ($root | path join registry)
let cache = '/Users/master/.cargo/registry/cache/index.crates.io-1949cf8c6b5b557f'
let packages = (open --raw ($root | path join sources honeycrisp Cargo.lock) | from toml | get package | where {|p| ($p | get -o source | default '') =~ '^registry'})
if ($dest | path exists) { error make {msg: 'fresh registry required'} }
mkdir $dest
mut receipts = []
for p in $packages {
    let archive = ($cache | path join $'($p.name)-($p.version).crate')
    if (open --raw $archive | hash sha256) != $p.checksum { error make {msg: $'archive checksum ($p.name)'} }
    let started = (date now | format date '%+')
    let result = (^tar -xzf $archive -C $dest | complete)
    if $result.exit_code != 0 { error make {msg: $result.stderr} }
    let pkg = ($dest | path join $'($p.name)-($p.version)')
    mut files = {}
    for f in (glob --no-dir ($pkg | path join '**/*')) {
        let key = ($f | path relative-to $pkg)
        $files = ($files | insert $key (open --raw $f | hash sha256))
    }
    {files: $files, package: $p.checksum} | to json | save ($pkg | path join .cargo-checksum.json)
    $receipts = ($receipts | append {name: $p.name, version: $p.version, package_sha256: $p.checksum, archive: $archive, archive_bytes: (open --raw $archive | into binary | bytes length), started: $started, finished: (date now | format date '%+'), argv: ['tar' '-xzf' $archive '-C' $dest], exit_code: $result.exit_code, stdout: $result.stdout, stderr: $result.stderr, files: $files})
}
$receipts | to json | save ($root | path join registry-acquisition.json)
cp ($root | path join cargo-home config.toml) ($root | path join initial-cargo-config.txt)
$'[source.crates-io]
replace-with = "official-cache"
[source.official-cache]
directory = "($dest)"
' | save --force ($root | path join cargo-home config.toml)
cp /tmp/unimem-core-registry.nu ($root | path join registry.nu)
print {packages: ($receipts | length), archive_bytes: ($receipts.archive_bytes | math sum), registry: $dest, downloaded: 0, changed_source: false}
