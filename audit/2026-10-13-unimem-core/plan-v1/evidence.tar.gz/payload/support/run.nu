def main [name: string, cwd: path, target: path, arguments: string] {
    let args = ($arguments | from json)
    let root = '/tmp/unimem-core-research'
    let record = ($root | path join records $name)
    if ($record | path exists) { error make {msg: 'immutable record already exists'} }
    mkdir $record
    let toolchain = '/Users/master/.rustup/toolchains/1.95.0-aarch64-apple-darwin/bin'
    let variables = {CARGO_HOME: ($root | path join cargo-home), CARGO_TARGET_DIR: $target, CARGO_BUILD_JOBS: '2', CARGO_INCREMENTAL: '0', RUSTC: ($toolchain | path join rustc), RUSTDOC: ($toolchain | path join rustdoc), RUSTFLAGS: '-Dwarnings', RUSTDOCFLAGS: '-Dwarnings', RUSTUP_TOOLCHAIN: '1.95.0', PATH: ([$toolchain] | append $env.PATH)}
    let runner = (open --raw /tmp/unimem-core-run.nu | hash sha256)
    let input_hash = (open --raw ($root | path join sources.json) | hash sha256)
    let argv = ([($toolchain | path join cargo)] | append $args)
    cd $cwd
    let started = (date now | format date '%+')
    let result = (with-env $variables { hide-env -i RUSTC_BOOTSTRAP; ^($argv.0) ...($argv | skip 1) | complete })
    let finished = (date now | format date '%+')
    $result.stdout | save --raw ($record | path join stdout)
    $result.stderr | save --raw ($record | path join stderr)
    {name: $name, cwd: $cwd, argv: $argv, env: ($variables | insert RUSTC_BOOTSTRAP null), started: $started, finished: $finished, exit_code: $result.exit_code, source_manifest_sha256: $input_hash, runner_sha256: $runner, stdout: {bytes: ($result.stdout | into binary | bytes length), sha256: ($result.stdout | hash sha256)}, stderr: {bytes: ($result.stderr | into binary | bytes length), sha256: ($result.stderr | hash sha256)}} | to json | save ($record | path join receipt.json)
    print {name: $name, exit_code: $result.exit_code, stderr_tail: ($result.stderr | lines | last 12), stdout_tail: ($result.stdout | lines | last 12)}
}
