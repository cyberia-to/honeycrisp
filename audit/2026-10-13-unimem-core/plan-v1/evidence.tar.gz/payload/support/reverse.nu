let root = '/tmp/unimem-core-research'
mut records = []
for name in [xena bita mir glia zoya perla evy nika trisha] {
    let repo = ($'/Users/master/cyber/($name)')
    let start = (date now | format date '%+')
    let head_args = ['git' '-C' $repo 'symbolic-ref' 'refs/remotes/origin/HEAD']
    let head = (^($head_args.0) ...($head_args | skip 1) | complete)
    if $head.exit_code != 0 {
        $records = ($records | append {name: $name, argv: $head_args, started: $start, result: $head, scope: 'local origin-tracking reference unavailable; no source substitute'})
        continue
    }
    let reference = ($head.stdout | str trim)
    let rev = (^git -C $repo rev-parse $reference | str trim)
    let args = ['git' '-C' $repo 'grep' '-n' '-E' 'honeycrisp|unimem|acpu|rane|aruminium' $rev '--' '*Cargo.toml']
    let result = (^($args.0) ...($args | skip 1) | complete)
    mut files = []
    for p in ($result.stdout | lines | parse --regex '^[^:]+:(?P<path>[^:]+):' | get path | uniq) {
        let body = (^git -C $repo show $'($rev):($p)' | complete)
        if $body.exit_code != 0 { error make {msg: $body.stderr} }
        let saved = ($root | path join inventory $name $'($p).txt')
        mkdir ($saved | path dirname)
        $body.stdout | save --raw $saved
        $files = ($files | append {path: $p, saved: ($saved | path relative-to $root), bytes: ($body.stdout | into binary | bytes length), sha256: ($body.stdout | hash sha256)})
    }
    $records = ($records | append {name: $name, reference: $reference, revision: $rev, argv: $args, started: $start, finished: (date now | format date '%+'), result: $result, files: $files, scope: 'committed local origin-tracking snapshot; no fresh network observation or build'})
}
$records | to json | save ($root | path join inventory reverse.json)
print ($records | each {|r| {name: $r.name, revision: ($r.revision? | default ''), manifests: ($r.files? | default [] | length), exit: $r.result.exit_code}})
