let root = '/tmp/unimem-core-research'
let repo = '/Users/master/cyber/honeycrisp-unimem-core'
mut checked = 0
for source in (open ($root | path join sources.json)) {
    for f in $source.files {
        let p = ($source.export | path join $f.path)
        if (open --raw $p | hash sha256) != $f.sha256 or (^stat -f '%Lp' $p | str trim) != ($f.mode | str substring 3..) { error make {msg: $'changed source ($p)'} }
        $checked = $checked + 1
    }
}
{checked: $checked, finished: (date now | format date '%+'), scope: 'after completed records 01 through 15; not a per-run source guard'} | to json | save ($root | path join source-post-gates.json)
let tag = '96fa4f4509d7a966cb22a4bb9e12ac753cff43ae'
let tag_dir = ($root | path join sources honeycrisp-tag)
mkdir $tag_dir
let tree = (^git -C $repo ls-tree -rl $tag | complete)
let archive = (^git -C $repo archive --format=tar $'--output=($root)/tag.tar' $tag | complete)
let extracted = (^tar -xf ($root | path join tag.tar) -C $tag_dir | complete)
if $tree.exit_code != 0 or $archive.exit_code != 0 or $extracted.exit_code != 0 { error make {msg: 'tag export failure'} }
mut files = []
for r in ($tree.stdout | lines | parse --regex '^(?P<mode>\S+) (?P<kind>\S+) (?P<blob>\S+) +(?P<bytes>\d+)\t(?P<path>.*)$') {
    if $r.kind != blob or $r.mode not-in ['100644' '100755'] { error make {msg: 'unexpected tag entry'} }
    let p = ($tag_dir | path join $r.path)
    let b = (open --raw $p | into binary)
    if ($b | ^git hash-object --stdin | str trim) != $r.blob or (^stat -f '%Lp' $p | str trim) != ($r.mode | str substring 3..) { error make {msg: 'tag identity failure'} }
    $files = ($files | append ($r | insert sha256 ($b | hash sha256)))
}
{revision: $tag, repository: $repo, archive_sha256: (open --raw ($root | path join tag.tar) | hash sha256), tree: $tree, archive: $archive, extracted: $extracted, files: $files} | to json | save ($root | path join tag.json)
let gate = ($root | path join gate-parent unimem scripts check-no-std.nu)
let variables = {CARGO_HOME: ($root | path join cargo-home), CARGO_BUILD_JOBS: '2', CARGO_INCREMENTAL: '0', RUSTUP_TOOLCHAIN: '1.95.0', RUSTFLAGS: '-Dwarnings', RUSTDOCFLAGS: '-Dwarnings'}
let started = (date now | format date '%+')
let result = (with-env $variables { ^nu $gate | complete })
let out = ($root | path join durable-parent-v1)
mkdir $out
$result.stdout | save --raw ($out | path join stdout)
$result.stderr | save --raw ($out | path join stderr)
{argv: ['nu' $gate], env: $variables, started: $started, finished: (date now | format date '%+'), exit_code: $result.exit_code, gate_sha256: (open --raw $gate | hash sha256), stdout_sha256: ($result.stdout | hash sha256), stderr_sha256: ($result.stderr | hash sha256)} | to json | save ($out | path join receipt.json)
print {source_files: $checked, tag_files: ($files | length), gate_exit: $result.exit_code, gate_stderr: $result.stderr}
