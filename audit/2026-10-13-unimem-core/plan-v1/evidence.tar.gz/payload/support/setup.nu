def capture [argv: list<string>, cwd: path] {
    cd $cwd
    let started = (date now | format date '%+')
    let r = (^($argv.0) ...($argv | skip 1) | complete)
    {argv: $argv, cwd: $cwd, started: $started, finished: (date now | format date '%+'), exit_code: $r.exit_code, stdout: $r.stdout, stderr: $r.stderr}
}
let root = '/tmp/unimem-core-research'
if ($root | path exists) { error make {msg: 'fresh research destination required'} }
mkdir $root
mkdir ($root | path join records)
mkdir ($root | path join sources)
mkdir ($root | path join cargo-home)
mkdir ($root | path join primary)
mut receipts = []
mut sources = []
for entry in [{name: honeycrisp, repo: '/Users/master/cyber/honeycrisp-unimem-core', rev: '9cbd48070a136e24711896c930670fcff8a147fc'}, {name: strata, repo: '/Users/master/cyber/strata', rev: '494df7a0973ae10a6cc1c2022e644d70449a29d6'}] {
    let remote = (capture ['git' 'ls-remote' 'origin' 'refs/heads/main'] $entry.repo)
    $receipts = ($receipts | append $remote)
    if $remote.exit_code != 0 or not ($remote.stdout | str starts-with $entry.rev) { error make {msg: 'origin source identity changed'} }
    let tree = (capture ['git' 'ls-tree' '-rl' $entry.rev] $entry.repo)
    $receipts = ($receipts | append $tree)
    if $tree.exit_code != 0 { error make {msg: $tree.stderr} }
    let tar = ($root | path join $'($entry.name).tar')
    let export = (capture ['git' 'archive' '--format=tar' $'--output=($tar)' $entry.rev] $entry.repo)
    $receipts = ($receipts | append $export)
    if $export.exit_code != 0 { error make {msg: $export.stderr} }
    let dest = ($root | path join sources $entry.name)
    mkdir $dest
    let extracted = (capture ['tar' '-xf' $tar '-C' $dest] $entry.repo)
    $receipts = ($receipts | append $extracted)
    if $extracted.exit_code != 0 { error make {msg: $extracted.stderr} }
    let rows = ($tree.stdout | lines | parse --regex '^(?P<mode>\S+) (?P<kind>\S+) (?P<blob>\S+) +(?P<bytes>\d+)\t(?P<path>.*)$')
    mut entries = []
    for r in $rows {
        if $r.kind != blob or $r.mode not-in ['100644' '100755'] { error make {msg: 'unexpected export entry kind'} }
        let p = ($dest | path join $r.path)
        let b = (open --raw $p | into binary)
        let blob = ($b | ^git hash-object --stdin | str trim)
        let mode = (^stat -f '%Lp' $p | str trim)
        if $blob != $r.blob or ($b | bytes length) != ($r.bytes | into int) or $mode != ($r.mode | str substring 3..) { error make {msg: $'export identity ($p)'} }
        $entries = ($entries | append {path: $r.path, mode: $r.mode, blob: $r.blob, bytes: ($r.bytes | into int), sha256: ($b | hash sha256)})
    }
    $sources = ($sources | append {name: $entry.name, revision: $entry.rev, repository: $entry.repo, export: $dest, archive_sha256: (open --raw $tar | hash sha256), files: $entries})
}
$receipts | to json | save ($root | path join setup-receipts.json)
$sources | to json | save ($root | path join sources.json)
let registry = '/Users/master/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f'
$'[source.crates-io]
replace-with = "official-cache"
[source.official-cache]
directory = "($registry)"
' | save ($root | path join cargo-home config.toml)
for package in ['crossbeam-queue-0.3.12' 'crossbeam-utils-0.8.21' 'mutants-0.0.3'] {
    let dest = ($root | path join primary $package)
    cp -r ($registry | path join $package) $dest
}
cp /tmp/kadek-root-capture.rb ($root | path join primary root-capture.rb)
mkdir ($root | path join history)
for p in (glob '/tmp/unimem-core-*.{json,stdout,stderr,txt}') { cp $p ($root | path join history ($p | path basename)) }
cp -r /tmp/unimem-core-consumer-parent ($root | path join consumer-frozen)
open --raw /tmp/unimem-core-setup.nu | save ($root | path join setup.nu)
print {sources: ($sources | select name revision | to json), entries: ($sources.files | flatten | length), production_change: false}
