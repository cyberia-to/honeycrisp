let root = '/tmp/unimem-core-research'
let drift = ($root | path join gate-drift)
mkdir ($drift | path join unimem)
cp ($root | path join gate-parent Cargo.toml) ($drift | path join Cargo.toml)
open --raw ($root | path join gate-parent Cargo.lock)
    | str replace '0f58bbc28f91df819d0aa2a2c00cd19754769c2fad90579b3592b1c9ba7a3115' '0f58bbc28f91df819d0aa2a2c00cd19754769c2fad90579b3592b1c9ba7a3116'
    | save ($drift | path join Cargo.lock)
cp ($root | path join gate-parent unimem Cargo.toml) ($drift | path join unimem Cargo.toml)
cp -r ($root | path join gate-parent unimem scripts) ($drift | path join unimem scripts)
cp -r ($root | path join gate-parent unimem fixtures) ($drift | path join unimem fixtures)
let argv = ['nu' ($drift | path join unimem scripts check-no-std.nu)]
let started = (date now | format date '%+')
let r = (^($argv.0) ...($argv | skip 1) | complete)
mkdir ($root | path join durable-drift-v1)
$r.stdout | save --raw ($root | path join durable-drift-v1 stdout)
$r.stderr | save --raw ($root | path join durable-drift-v1 stderr)
{argv: $argv, started: $started, finished: (date now | format date '%+'), exit_code: $r.exit_code, changed_input: 'one final checksum nibble of workspace crossbeam-queue 0.3.12; no production file', stderr_sha256: ($r.stderr | hash sha256), stdout_sha256: ($r.stdout | hash sha256)} | to json | save ($root | path join durable-drift-v1 receipt.json)
if $r.exit_code == 0 or not ($r.stderr | str contains 'no_std fixture dependency drift: crossbeam-queue') { error make {msg: 'drift witness did not discriminate'} }
let cargo = (which cargo | first | get path)
let rustc = (which rustc | first | get path)
{cargo: $cargo, cargo_sha256: (open --raw $cargo | hash sha256), cargo_version: (^cargo --version), rustc: $rustc, rustc_sha256: (open --raw $rustc | hash sha256), rustc_version: (^rustc -vV), nu_version: (version | get version), note: 'durable-parent-v1 invoked caller PATH Homebrew Rust 1.95, unlike numbered records Rustup 1.95; RUSTUP_TOOLCHAIN does not choose non-rustup Cargo'} | to json | save ($root | path join durable-tools.json)
print {exit: $r.exit_code, expected_drift_error: true}
