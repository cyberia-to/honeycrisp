//! Native integration control; test harness uses std, unimem features remain isolated.
