let root = '/tmp/unimem-core-research'
let source = ($root | path join sources honeycrisp)
mut identities = []
for kind in [compile native std] {
    let dest = ($root | path join $'consumer-($kind)-parent')
    if ($dest | path exists) { error make {msg: 'consumer already exists'} }
    mkdir ($dest | path join src)
    let name = (if $kind == compile { 'unimem-core-consumer' } else { $'unimem-($kind)-consumer' })
    let defaults = (if $kind == std { 'true' } else { 'false' })
    let abort = (if $kind == compile { "[profile.dev]\npanic = \"abort\"\n" } else { '' })
    $'[package]
name = "($name)"
version = "0.0.0"
edition = "2021"
[workspace]
[dependencies]
unimem = { path = "($source)/unimem", default-features = ($defaults) }
($abort)' | save ($dest | path join Cargo.toml)
    let original_lock = (open --raw ($root | path join consumer-frozen Cargo.lock))
    ($original_lock | str replace 'name = "unimem-core-consumer"' $'name = "($name)"') | save ($dest | path join Cargo.lock)
    if $kind == compile {
        cp ($root | path join consumer-frozen src main.rs) ($dest | path join src main.rs)
    } else if $kind == std {
        "fn main() { let plan = unimem::Block::plan(1).unwrap(); assert!(plan.allocation_size() >= 1); }\n" | save ($dest | path join src main.rs)
    } else {
        "//! Native integration control; test harness uses std, unimem features remain isolated.\n" | save ($dest | path join src lib.rs)
        cp -r ($source | path join unimem tests) ($dest | path join tests)
    }
    let files = (glob --no-dir ($dest | path join '**/*') | each {|p| {path: ($p | path relative-to $dest), bytes: (open --raw $p | into binary | bytes length), sha256: (open --raw $p | hash sha256)}})
    $identities = ($identities | append {kind: $kind, path: $dest, files: $files})
}
$identities | to json | save ($root | path join consumer-inputs.json)
cp /tmp/unimem-core-consumers.nu ($root | path join consumers.nu)
print ($identities | select kind path)
