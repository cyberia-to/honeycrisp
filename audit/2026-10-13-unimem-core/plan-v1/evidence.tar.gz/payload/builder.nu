let root = '/tmp/unimem-core-research'
let work = '/Users/master/cyber/honeycrisp-unimem-core'
let pack = '/tmp/unimem-core-plan-v1'
if ($pack | path exists) { error make {msg: 'fresh packet directory required'} }
mkdir ($pack | path join support)
let support = ($pack | path join support)
for p in [sources.json source-post-gates.json tag.json registry-acquisition.json consumer-inputs.json setup-receipts.json durable-tools.json initial-cargo-config.txt run.nu setup.nu consumers.nu] { cp ($root | path join $p) ($support | path join $p) }
for p in [records history inventory primary consumer-frozen consumer-compile-parent consumer-native-parent consumer-std-parent durable-parent-v1 durable-drift-v1] { cp -r ($root | path join $p) ($support | path join $p) }
for p in [honeycrisp.tar strata.tar tag.tar] { cp ($root | path join $p) ($support | path join $p) }
mkdir ($support | path join parent)
for p in [Cargo.toml Cargo.lock CLAUDE.md LICENSE unimem] { cp -r ($root | path join sources honeycrisp $p) ($support | path join parent $p) }
cp -r /tmp/unimem-core-gate-draft/unimem ($support | path join proposed)
mkdir ($support | path join task)
for p in [research.md plan.md] { cp ($work | path join .claude tasks unimem-core $p) ($support | path join task $p) }
cp /tmp/unimem-core-plan-brief.txt ($support | path join brief.txt)
cp /tmp/unimem-core-preparation.txt ($support | path join preparation.txt)
mkdir ($support | path join rules)
cp /Users/master/cyber/AGENTS.md ($support | path join rules AGENTS.md)
cp /Users/master/cyber/cyberia/dev.md ($support | path join rules dev.md)
for name in [finite inventory reverse gate-drift] { cp $'/tmp/unimem-core-($name).nu' ($support | path join $'($name).nu') }
cp /tmp/unimem-core-registry.nu ($support | path join registry.nu)
let summary = (glob ($root | path join records '*' receipt.json) | sort | each {|p|
    let r = (open $p)
    {name: $r.name, argv: $r.argv, cwd: $r.cwd, exit_code: $r.exit_code, started: $r.started, finished: $r.finished, receipt: ($p | path relative-to $root), receipt_sha256: (open --raw $p | hash sha256), stdout_sha256: $r.stdout.sha256, stderr_sha256: $r.stderr.sha256}
})
$summary | to json | save ($support | path join commands.json)
mut requested = [
 {path: brief.txt, label: 'Review scope and questions'},
 {path: task/research.md, label: 'Research and measured boundaries'},
 {path: task/plan.md, label: 'Formal PLAN'},
 {path: preparation.txt, label: 'Preparation failures and attribution'},
 {path: rules/AGENTS.md, label: 'Governing repository rules'},
 {path: rules/dev.md, label: 'Governing workflow/rings/review excerpt', first: 29, last: 87},
 {path: parent/CLAUDE.md, label: 'Owning repository rules and gates'},
 {path: parent/unimem/CLAUDE.md, label: 'Owning driver rules and gates'},
 {path: parent/Cargo.toml, label: 'Exact parent workspace manifest'},
 {path: parent/unimem/Cargo.toml, label: 'Exact parent unimem manifest'},
 {path: parent/unimem/README.md, label: 'Existing README receiving a small usage addition'},
 {path: parent/unimem/specs/README.md, label: 'Canonical allocation/access/Tape/Grid contracts', first: 108, last: 306},
 {path: parent/unimem/specs/README.md, label: 'Canonical dependency and scope excerpt', first: 363, last: 400}
]
for p in [lib.rs block.rs ffi.rs tape.rs grid.rs layout.rs block/creation.rs block/tests.rs] { $requested = ($requested | append {path: $'parent/unimem/src/($p)', label: $'Full existing source ($p)'}) }
for p in [block_access.rs block_creation.rs roundtrip.rs] { $requested = ($requested | append {path: $'parent/unimem/tests/($p)', label: $'Frozen native integration body ($p)'}) }
for p in [scripts/check-no-std.nu fixtures/no-std/consumer.rs fixtures/no-std/Cargo.toml.txt fixtures/no-std/Cargo.lock.txt] { $requested = ($requested | append {path: $'proposed/($p)', label: $'Exact proposed durable gate ($p)'}) }
for p in [crossbeam-queue-0.3.12/Cargo.toml crossbeam-queue-0.3.12/src/lib.rs crossbeam-utils-0.8.21/Cargo.toml crossbeam-utils-0.8.21/src/lib.rs crossbeam-utils-0.8.21/src/backoff.rs crossbeam-utils-0.8.21/build.rs mutants-0.0.3/Cargo.toml] { $requested = ($requested | append {path: $'primary/($p)', label: $'Exact primary dependency source ($p)'}) }
for p in [consumer-compile-parent/Cargo.toml consumer-compile-parent/src/main.rs consumer-native-parent/Cargo.toml consumer-std-parent/Cargo.toml consumer-std-parent/src/main.rs] { $requested = ($requested | append {path: $p, label: $'Frozen parent control ($p)'}) }
$requested = ($requested | append {path: commands.json, label: 'Complete numbered command/result/stream index'})
for p in [03-parent-native/stdout 04-parent-no-std-consumer/receipt.json 04-parent-no-std-consumer/stderr 05-parent-std-consumer/stderr 06-parent-isolated-native/stdout 07-parent-isolated-features/stdout 10-parent-clippy/stderr 13-parent-normal-features/stdout 16-tag-metadata/stderr 17-parent-versus-tag-api/stderr] { $requested = ($requested | append {path: $'records/($p)', label: $'Complete parent raw evidence ($p)'}) }
for p in [durable-parent-v1/receipt.json durable-parent-v1/stderr durable-drift-v1/receipt.json durable-drift-v1/stderr inventory/primary-parity.json] { $requested = ($requested | append {path: $p, label: $'Gate/primary verification ($p)'}) }
mut sections = []
mut chunks = []
for pair in ($requested | enumerate) {
    let r = $pair.item
    let text = (open --raw ($support | path join $r.path))
    let all = ($text | into binary)
    let offset = (if $r.first? == null or $r.first == 1 { 0 } else { ($text | split row "\n" | first ($r.first - 1) | str join "\n" | into binary | bytes length) + 1 })
    let size = (if $r.first? == null { $all | bytes length } else { ($text | split row "\n" | skip ($r.first - 1) | first ($r.last - $r.first + 1) | str join "\n" | into binary | bytes length) + 1 })
    let b = ($all | bytes at $offset..<($offset + $size))
    let row = {label: $r.label, path: $r.path, source_bytes: ($all | bytes length), source_sha256: ($all | hash sha256), byte_offset: $offset, bytes: $size, sha256: ($b | hash sha256)}
    $sections = ($sections | append $row)
    $chunks = ($chunks | append $"\n===== ($pair.index + 1). ($r.label) | ($r.path) @($offset)+($size) SHA256 ($row.sha256) =====\n" | append ($b | decode utf-8) | append "\n")
}
let footer = "\nEND. Full indexed support is retained beside this readable packet. Hash-only omitted source bodies are not claimed to have been read by the reviewer. Review this PLAN; no candidate source or implementation approval is asserted.\n"
$footer | save --raw ($pack | path join footer.txt)
$chunks | append $footer | str join | save --raw ($pack | path join review.txt)
$sections | to json | save ($pack | path join sections.json)
let files = (glob --no-dir ($support | path join '**/*') | sort | each {|p| let b = (open --raw $p | into binary); {path: ($p | path relative-to $pack), bytes: ($b | bytes length), sha256: ($b | hash sha256)}})
$files | to json | save ($pack | path join support-files.json)
{kind: 'Unimem core PLAN v1; no production changed', parent: '9cbd48070a136e24711896c930670fcff8a147fc', sections: ($sections | length), support_files: ($files | length), review_bytes: (open --raw ($pack | path join review.txt) | into binary | bytes length), review_sha256: (open --raw ($pack | path join review.txt) | hash sha256), sections_sha256: (open --raw ($pack | path join sections.json) | hash sha256), support_sha256: (open --raw ($pack | path join support-files.json) | hash sha256), footer_sha256: ($footer | hash sha256)} | to json | save ($pack | path join manifest.json)
open ($pack | path join manifest.json) | print
